const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
//Routes
app.use("/api/users", require("./routes/loginRoutes"));

const constant = require("./config/constant");

app.listen(constant.PORT, console.log("app is running " + constant.PORT));
