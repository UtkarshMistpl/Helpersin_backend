const { application } = require("express");
const express = require("express");
const router = express.Router();

const { loginUser, registerUser } = require("../controllers/loginController");
const { addUser } = require("../controllers/userController");
const { formValidator } = require("../utils/util");

router.post("/login", loginUser);
router.post("/signup", formValidator, addUser);
module.exports = router;
