const { hash } = require("bcrypt");
const db = require("../models");
const { createToken, verifyPassword, createHash } = require("../utils/util");
const { validationResult } = require("express-validator");

const Users = db.users;

const addUser = async (req, res) => {
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors);
		return res.json({ status: 0, message: errors });
	}

	const { name, email, mobile, username, role, status, password, cpassword } =
		req.body;

	if (password !== cpassword)
		res.json({ status: 0, message: "confirm password did not match" });

	let hashpass = await createHash(password);

	let emailCheck = await Users.findOne({ where: { email: email } });

	if (emailCheck !== null) {
		res.json({ status: 0, message: "Email Already Exists" });
	} else {
		let data = {
			name: name,
			email: email,
			mobile: mobile,
			username: username,
			role: role,
			password: hashpass,
			status: status,
		};

		let user = await Users.create(data);

		if (user !== undefined) {
			const token = createToken(user.dataValues);
			const data = {
				id: user.dataValues.id,
				username: user.dataValues.username,
				email: user.dataValues.email,
				appRoleId: user.dataValues.role,
			};
			res.json({ status: "success", token: token, user: data });
		} else {
			res.json({ status: "error", message: "failed to create user" });
		}
	}
};

module.exports = {
	addUser,
};
